package com.mashibing.dp.bridge.v1;

public class GG {
    public void chase(MM mm) {
        Gift g = new Book();
        give(mm, g);
    }

    public void give(MM mm, Gift g) {

    }


}
