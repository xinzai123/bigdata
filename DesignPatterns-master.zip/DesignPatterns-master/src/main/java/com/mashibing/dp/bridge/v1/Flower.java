package com.mashibing.dp.bridge.v1;

public class Flower extends Gift {
}
