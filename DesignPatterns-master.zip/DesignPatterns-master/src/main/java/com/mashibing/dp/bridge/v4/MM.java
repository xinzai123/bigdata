package com.mashibing.dp.bridge.v4;

public class MM {
    String name;
}
