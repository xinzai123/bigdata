package com.mashibing.dp.abstractfactory;

public class MushRoom extends Food{
    public void printName() {
        System.out.println("dmg");
    }
}
