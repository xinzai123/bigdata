package com.mashibing.dp.command;

public class Content {
    String msg = "hello everybody ";

}
