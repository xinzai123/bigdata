package com.mashibing.dp.factorymethod;

public class Plane implements Moveable {
    public void go() {
        System.out.println("plane flying shushua....");
    }
}
