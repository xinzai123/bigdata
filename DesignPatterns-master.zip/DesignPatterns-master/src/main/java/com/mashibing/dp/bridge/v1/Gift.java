package com.mashibing.dp.bridge.v1;

public abstract class Gift {}
