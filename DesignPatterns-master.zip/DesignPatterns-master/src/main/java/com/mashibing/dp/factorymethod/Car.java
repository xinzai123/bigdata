package com.mashibing.dp.factorymethod;

public class Car implements  Moveable {

    public void go() {
        System.out.println("Car go wuwuwuwuw....");
    }
}
