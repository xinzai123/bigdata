package com.mashibing.dp.factorymethod;

public interface Moveable {
    void go();
}
