package com.mashibing.dp.ASM;

public class Main {
    public static void main(String[] args) {
        new T1();
    }
}
