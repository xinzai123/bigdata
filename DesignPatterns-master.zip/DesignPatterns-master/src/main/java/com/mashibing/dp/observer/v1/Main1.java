package com.mashibing.dp.observer.v1;

/**
 * 披着面向对象外衣的面向过程
 */

public class Main1 {
    public static void main(String[] args) {
        boolean cry = false;

        while(!cry) {
            //进行处理
        }
    }
}
