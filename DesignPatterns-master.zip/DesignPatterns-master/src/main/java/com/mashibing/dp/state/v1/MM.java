package com.mashibing.dp.state.v1;

/**
 * 当增加新的状态时非常不方便
 */

public class MM {
    String name;
    private enum MMState {HAPPY, SAD}
    MMState state;

    public void smile() {
        //switch case

    }

    public void cry() {
        //switch case
    }

    public void say() {
        //switch case
    }
}
